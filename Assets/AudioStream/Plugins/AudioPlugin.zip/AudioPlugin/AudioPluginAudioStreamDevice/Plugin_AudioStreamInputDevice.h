// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once
#include "FMODDevice.h"

namespace AudioStreamInputDevice
{
    enum Param
    {
        P_INPUTDEVICEID
        // , P_DSPBUFFERLENGTH
        // , P_DSPBUFFERCOUNT
        , P_NUM
    };
    /// <summary>
    /// 
    /// </summary>
    struct EffectData
    {
        /// <summary>
        /// User/Unity mixer effect parameters
        /// </summary>
        float parameters[P_NUM];
        /// <summary>
        /// 
        /// </summary>
        // FMOD::System* recSystem; == 0
        /// <summary>
        /// parameters[P_INPUTDEVICEID]
        /// </summary>
        FMOD::Sound* recSound;
    };
}
