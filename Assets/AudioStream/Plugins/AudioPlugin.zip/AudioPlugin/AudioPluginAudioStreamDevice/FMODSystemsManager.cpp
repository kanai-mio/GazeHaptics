// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#include "FMODSystemsManager.h"
#include "FMODDevice.h"
#include <map>

/// <summary>
/// - single system (0) for notifications about devices changes
/// - recording system
/// - ASIO requires exclusive single system
/// </summary>
extern AudioStreamDevice::FMODDevice* default0_system;
/* !notif
* */
/// <summary>
/// !1 run
/// </summary>
extern bool invalidate_devices = false;

namespace AudioStreamDevice
{
    std::map<AudioStreamOutputDevice::EffectData*, bool> invalidate_effectdataO;
    std::map<AudioStreamInputDevice::EffectData*, bool> invalidate_effectdataI;

    FMODDevice* OutputSystem(AudioStreamOutputDevice::EffectData* fromData)
    {
        if (use_ASIO)
        {
            // conflate all outputs to single one
            return default0_system;
        }
        else
        {
            auto outputDeviceID = fromData->parameters[AudioStreamOutputDevice::P_OUTPUTDEVICEID];
            auto it = outputSystems.find((UInt32)outputDeviceID);
            if (it != outputSystems.end())
                return it->second;
        }

        return NULL;
    }

    FMODDevice* InputSystem(AudioStreamInputDevice::EffectData* fromData)
    {
        return default0_system;
    }
#pragma region Output
    void ProcessCallbackForOutputDevice(AudioStreamOutputDevice::EffectData*data, float* inbuffer, unsigned int length, int inchannels, UInt32 samplerate)
    {
        AudioPluginUtil::MutexScopeLock m1(outputMutex);

        FMODDevice* system = OutputSystem(data);
        if (system == NULL
            && !use_ASIO // guard
            )
        {
            auto outputDeviceID = (UInt32)data->parameters[AudioStreamOutputDevice::P_OUTPUTDEVICEID];
            system = outputSystems[outputDeviceID] = new FMODDevice(outputDeviceID, samplerate, NULL);
        }

        if (data->outputSound == NULL)
        {
            StartOutputSound(data, inchannels, samplerate);
            system->Update();
        }

        // forward the inbuffer
        system->Feed(data->outputSound, inbuffer, length * inchannels);
    }

    void MuteOutputSound(AudioStreamOutputDevice::EffectData* data)
    {
        AudioPluginUtil::MutexScopeLock m1(outputMutex);

        FMODDevice* system = OutputSystem(data);
        if (system == NULL)
            return;

        system->MuteOutputSound(data->outputSound);
    }

    void UnmuteOutputSound(AudioStreamOutputDevice::EffectData* data)
    {
        AudioPluginUtil::MutexScopeLock m1(outputMutex);

        FMODDevice* system = OutputSystem(data);
        if (system == NULL)
            return;

        system->UnmuteOutputSound(data->outputSound);
    }

    void StartOutputSound(AudioStreamOutputDevice::EffectData* data, int inchannels, UInt32 insamplerate)
    {
        AudioPluginUtil::MutexScopeLock m1(outputMutex);

        FMODDevice* system = OutputSystem(data);
        if (system == NULL)
            return;

        system->StartOutputSound(&data->outputSound, inchannels, insamplerate);
    }

    void StopOutputSound(AudioStreamOutputDevice::EffectData* data)
    {
        AudioPluginUtil::MutexScopeLock m1(outputMutex);

        FMODDevice* system = OutputSystem(data);
        if (system != NULL)
            system->StopOutputSound(data->outputSound);

        data->outputSound = NULL;
    }
#pragma endregion
#pragma region Input
    void ProcessCallbackForRecording(AudioStreamInputDevice::EffectData* data, float* outbufer, unsigned int length, int outchannels, UInt32 samplerate)
    {
        FMODDevice* system = InputSystem(data);
        if (system == NULL)
            return; // TF

        if (data->recSound == NULL)
        {
            auto inputID = (UInt32)data->parameters[AudioStreamInputDevice::P_INPUTDEVICEID];
            StartRecording(data, inputID, outchannels, samplerate);
        }

        system->UpdateRecording(outbufer, length, outchannels);
    }

    void StartRecording(AudioStreamInputDevice::EffectData* data, unsigned int ofInput, int channels, UInt32 samplerate)
    {
        FMODDevice* system = InputSystem(data);
        if (system == NULL)
            return; // TF

        system->StartRecording(&data->recSound, ofInput, channels, samplerate);
    }

    void StopRecording(AudioStreamInputDevice::EffectData* data)
    {
        FMODDevice* system = InputSystem(data);
        if (system == NULL)
            return; // TF/config

        system->StopRecording();

        data->recSound = NULL;
    }
#pragma endregion
    /* !notif
    */
#pragma region Notification cb
    void DevicesChanged()
    {
        for (auto it = invalidate_effectdataI.begin(); it != invalidate_effectdataI.end(); ++it)
            invalidate_effectdataI[it->first] = true;

        for (auto it = invalidate_effectdataO.begin(); it != invalidate_effectdataO.end(); ++it)
            invalidate_effectdataO[it->first] = true;

#if !PLATFORM_OSX
        invalidate_devices = true;
#endif
    }

#pragma endregion
#pragma region Notification cb
    void ReleaseAllDevices()
    {
        AudioPluginUtil::MutexScopeLock m1(outputMutex);

        for (auto it = outputSystems.begin(); it != outputSystems.end(); ++it)
            delete it->second;

        outputSystems.clear();

        if (default0_system)
        {
            delete default0_system;
            default0_system = NULL;
        }
    }
#pragma endregion
}
