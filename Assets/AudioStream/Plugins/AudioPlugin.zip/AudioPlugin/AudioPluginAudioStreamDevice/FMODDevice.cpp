// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#include "FMODDevice.h"
#include <algorithm>
#if !PLATFORM_WIN
#include <unistd.h> // macOS usleep, clang
#endif

/// <summary>
/// - single system (0) for notifications about devices changes
/// - recording system
/// - ASIO requires exclusive single system
/// </summary>
extern AudioStreamDevice::FMODDevice* default0_system = NULL;

namespace AudioStreamDevice
{
#pragma region pcmreadcallback
    // 7.1 - 384000 floats requested
    // some reserve
    static std::map<FMOD::Sound*, AudioPluginUtil::RingBuffer<1000000>*> pcmbuffers;

    FMOD_RESULT F_CALLBACK pcmreadcallback(FMOD_SOUND* sound, void* data, unsigned int datalen)
    {
        float* fdata = (float*)data;
        auto length = datalen >> 2; // sizeof(float) == 4

        memset(data, 0, datalen);

        void* reads = 0;
        ((FMOD::Sound*)sound)->getUserData((void**)&reads);

        if (!reads)
            return FMOD_OK;

        //auto pbuf = pcmbuffers[(FMOD::Sound*)sound];
        //if (pbuf)
        //{
        //}

        auto it = pcmbuffers.find((FMOD::Sound*)sound);
        if (it == pcmbuffers.end())
            return FMOD_OK;

        auto pcmbuffer = it->second;
        if (pcmbuffer)
            for (unsigned int n = 0; n < length; n++)
                pcmbuffer->Read(fdata[n]);

        return FMOD_OK;
    }

    FMOD_RESULT F_CALLBACK pcmsetposcallback(FMOD_SOUND* /*sound*/, int /*subsound*/, unsigned int /*position*/, FMOD_TIMEUNIT /*postype*/)
    {
        /*
        This is useful if the user calls Channel::setPosition and you want to seek your data accordingly.
        */
        return FMOD_OK;
    }

    /* !notif
    */
    FMOD_RESULT F_CALLBACK SystemCallback(FMOD_SYSTEM* system, FMOD_SYSTEM_CALLBACK_TYPE type, void* commanddata1, void* commanddata2, void* userdata)
    {
        printf("\n%d\n", (FMOD_SYSTEM_CALLBACK_TYPE)type);

        if (
            (type & FMOD_SYSTEM_CALLBACK_RECORDLISTCHANGED)
            )
        {
            if (userdata)
                ((FMODDevice*)userdata)->Notification_Callback();
        }

        return FMOD_OK;
    }
#pragma endregion
#pragma region capture DSP
    typedef struct
    {
        FMODDevice* instance;
    } mydsp_data_t;

    FMOD_RESULT F_CALLBACK readDSPCallback(FMOD_DSP_STATE* dsp_state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int* outchannels)
    {
        /*
            This loop assumes inchannels = outchannels, which it will be if the DSP is created with '0'
            as the number of channels in FMOD_DSP_DESCRIPTION.
            Specifying an actual channel count will mean you have to take care of any number of channels coming in,
            but outputting the number of channels specified. Generally it is best to keep the channel
            count at 0 for maximum compatibility.
        */
        void* userdata;
        FMOD_RESULT result = dsp_state->functions->getuserdata(dsp_state, &userdata);
        ERRCHECK(result);
        FMODDevice* inst = (FMODDevice*)userdata;

        for (unsigned int i = 0; i < length * inchannels; i++)
        {
            inst->recBuffer.Feed(inbuffer[i]);
        }

        //FMOD_SPEAKERMODE mixer, output;
        //result = dsp_state->functions->getspeakermode(dsp_state, &mixer, &output);
        //ERRCHECK(result);

        //int rate;
        //result = dsp_state->functions->getsamplerate(dsp_state, &rate);
        //ERRCHECK(result);

        return FMOD_ERR_DSP_SILENCE;
    }
    //FMOD_RESULT F_CALLBACK shouldiprocessDSPCallback(FMOD_DSP_STATE* dsp_state, FMOD_BOOL inputsidle, unsigned int length, FMOD_CHANNELMASK inmask, int inchannels, FMOD_SPEAKERMODE speakermode)
    //{
    //    void* userdata;
    //    FMOD_RESULT result = dsp_state->functions->getuserdata(dsp_state, &userdata);
    //    ERRCHECK(result);

    //    FMODDevice* inst = (FMODDevice*)userdata;
    //    
    //    return FMOD_OK;
    //    // return FMOD_ERR_DSP_DONTPROCESS;
    //}
#pragma endregion
#pragma region FMOD system
    FMODDevice::FMODDevice(UInt32 outputDeviceID, UInt32 samplerate, void(*notification_cb)())
    {
        /*
        Create a System object and initialize.
        */
        result = FMOD::System_Create(&system);
        ERRCHECK(result);

        result = system->getVersion(&version);
        ERRCHECK(result);

        if (version < FMOD_VERSION)
        {
            Common_Fatal("FMOD lib version %08x doesn't match header version %08x", version, FMOD_VERSION);
        }

        // Windows PC: 1024 / 4
        // unsigned int dlenght;
        // int dcount;
        // system->getDSPBufferSize(&dlenght, &dcount);
        // ERRCHECK(result);

        // result = system->setDSPBufferSize(dspBLength, dspBCount);
        // ERRCHECK(result);

        if (use_ASIO)
        {
            result = system->setOutput(FMOD_OUTPUTTYPE_ASIO);
            ERRCHECK(result);

            result = system->setDSPBufferSize(ASIO_bufferlength, ASIO_numbuffers);
            ERRCHECK(result);

            unsigned int dlenght;
            int dcount;
            result =  system->getDSPBufferSize(&dlenght, &dcount);
            ERRCHECK(result);

            printf("> ASIO buffers: %d %d\n", dlenght, dcount);
        }

        result = system->setSoftwareFormat(samplerate, FMOD_SPEAKERMODE_DEFAULT, 0);
        ERRCHECK(result);

        // max. virtual channels for init
        result = system->init(100, FMOD_INIT_NORMAL, NULL);
        ERRCHECK(result);

        if (notification_cb)
        {
            //result = system->setDriver(0);
            //ERRCHECK(result);

            this->notifcation_callback = notification_cb;

            // CB instance
            result = system->setUserData((void*)this);
            ERRCHECK(result);

            // install callback for FMOD_SYSTEM_CALLBACK_RECORDLISTCHANGED only
            // - it looks like that captures also changes on output devices (capture driver?)
            // (FMOD_SYSTEM_CALLBACK_DEVICELISTCHANGED doesn't capture e.g. changing default output)
            // each notification is processed separately - so there woudl be also two callbacks..

            /* !notif
            */
            result = system->setCallback(&SystemCallback
                , FMOD_SYSTEM_CALLBACK_RECORDLISTCHANGED // | FMOD_SYSTEM_CALLBACK_DEVICELISTCHANGED
            );
            ERRCHECK(result);
        }
        else
        {
            result = system->setDriver(outputDeviceID);
            ERRCHECK(result);
        }

        // class init. warnings
        this->recSound = NULL;
        this->recChannel = NULL;
        this->recCaptureDSP = NULL;
        this->recId = -1;
        this->driftThreshold = 0;
        this->desiredLatency = 0;
        this->adjustedLatency = 0;
        this->actualLatency = 0;
    }

    FMODDevice::~FMODDevice()
    {
        if (!this->system)
            return;
        /*
        Shut down
        */

        // update the system before release to possibly not hang up on system close
        this->Update();

        while (this->outputSounds.size() > 0)
            this->StopOutputSound(this->outputSounds.front());

        this->StopRecording();

#if PLATFORM_OSX
        usleep(50000);
#else
        Sleep(50);
#endif

        // AudioDeviceStop - CoreAudio`HALB_Mutex::Lock
#if !PLATFORM_OSX
        // This will internally call System::close, so calling System::close before this function is not necessary.
        result = this->system->release();
        ERRCHECK(result);
#endif

        this->system = NULL;
    }

    void FMODDevice::Update()
    {
        result = system->update();
        ERRCHECK(result);
    }
#pragma endregion
#pragma region Output
    void FMODDevice::MuteOutputSound(FMOD::Sound* sound)
    {
        pcmbuffers[sound]->SyncWritePos();

        result = sound->setUserData(NULL);
        ERRCHECK(result);
    }

    void FMODDevice::UnmuteOutputSound(FMOD::Sound* sound)
    {
        result = sound->setUserData((void*)this);
        ERRCHECK(result);
    }

    void FMODDevice::StartOutputSound(FMOD::Sound** sound, int inchannels, UInt32 insamplerate)
    {
        // create sound

        // directly affects latency, can't be a second (insamplerate) long..
        auto decodebuffersize = 1024; // screw this and hardcode it on windows for now..  FastMax(insamplerate / 40.0f, 1024);

        /*
        Create and play the sound.
        */
        FMOD_CREATESOUNDEXINFO  exinfo;

        memset(&exinfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));
        exinfo.numchannels = inchannels;                                                        /* Number of channels in the sound. */
        exinfo.defaultfrequency = insamplerate;                                                 /* Default playback rate of sound. */
        // v this is directly latency related
        exinfo.decodebuffersize = decodebuffersize;                                             /* Chunk size of stream update in samples. This will be the amount of data passed to the user callback. */
        exinfo.length = exinfo.defaultfrequency * exinfo.numchannels * sizeof(float);           /* Length of PCM data in bytes of whole song (for Sound::getLength) */
        exinfo.format = FMOD_SOUND_FORMAT_PCMFLOAT;                                             /* Data format of sound. */
        exinfo.pcmreadcallback = pcmreadcallback;                                               /* User callback for reading. */
        exinfo.pcmsetposcallback = pcmsetposcallback;                                           /* User callback for seeking. */
        exinfo.userdata = (void*)this;
        exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);                                         /* Required. */
        FMOD_MODE   mode = FMOD_OPENUSER | FMOD_LOOP_NORMAL | FMOD_CREATESTREAM;

        result = system->createSound(0, mode, &exinfo, sound);
        ERRCHECK(result);

        pcmbuffers[*sound] = new AudioPluginUtil::RingBuffer<1000000>();

        FMOD::Channel* channel;
        result = system->playSound(*sound, 0, 0, &channel);
        ERRCHECK(result);

        this->outputSounds.push_back(*sound);
    }

    void FMODDevice::StopOutputSound(FMOD::Sound* sound)
    {
        auto it = std::find(this->outputSounds.begin(), this->outputSounds.end(), sound);
        if (it != this->outputSounds.end())
        {
            result = (*it)->release();
            ERRCHECK(result);

#if PLATFORM_OSX
            usleep(50000);
#else
            Sleep(50);
#endif
            this->Update();

            // delete buffer
            auto pcmbit = pcmbuffers.find(*it);
            if (pcmbit != pcmbuffers.end())
            {
                delete pcmbit->second;
                pcmbuffers.erase(*it);
            }

            this->outputSounds.remove(*it);
        }
    }

    void FMODDevice::Feed(FMOD::Sound* sound, const float* input, unsigned int length)
    {
        auto pcmbuffer = pcmbuffers[sound];
        if (pcmbuffer)
            for (unsigned int n = 0; n < length; n++)
                pcmbuffer->Feed(input[n]);
    }
#pragma endregion
#pragma region Input
    // FMOD SoundSystem\FMOD Studio API Windows\api\core\examples\record.cpp
    // Record example record & playSound & drift compensation
    // sound un/lock https://fmod.com/docs/2.02/api/core-api-sound.html#sound_lock

    void FMODDevice::StartRecording(FMOD::Sound** toSound, unsigned int ofInput, int channels, UInt32 samplerate)
    {
        this->StopRecording();

        int numDrivers = 0;
        result = system->getRecordNumDrivers(NULL, &numDrivers);
        ERRCHECK(result);

        if (numDrivers == 0)
        {
            Common_Fatal("No recording devices found/plugged in!  Aborting.");
            return;
        }

        this->recId = ofInput;

        /*
            Determine latency in samples.
        */

        result = system->getRecordDriverInfo(this->recId, NULL, 0, NULL, &nativeRate, NULL, &nativeChannels, NULL);
        ERRCHECK(result);
        nativeRate = samplerate;
        nativeChannels = channels;

        driftThreshold = (nativeRate * DRIFT_MS) / 1000;       /* The point where we start compensating for drift */
        desiredLatency = (nativeRate * LATENCY_MS) / 1000;     /* User specified latency */
        adjustedLatency = desiredLatency;                      /* User specified latency adjusted for driver update granularity */
        actualLatency = desiredLatency;                                 /* Latency measured once playback begins (smoothened for jitter) */

        this->samplesRecorded = 0;
        this->samplesPlayed = 0;
        this->lastRecordPos = 0;
        /*
            Create user sound to record into, then start recording.
        */
        FMOD_CREATESOUNDEXINFO exinfo = { 0 };
        exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
        exinfo.numchannels = nativeChannels;
        exinfo.format = FMOD_SOUND_FORMAT_PCMFLOAT;
        exinfo.defaultfrequency = nativeRate;
        exinfo.length = nativeRate * channelSize * nativeChannels; /* 1 second buffer, size here doesn't change latency */

        result = system->createSound(0, FMOD_LOOP_NORMAL | FMOD_OPENUSER, &exinfo, &this->recSound);
        ERRCHECK(result);

        result = system->recordStart(this->recId, this->recSound, true);
        ERRCHECK(result);

        result = this->recSound->getLength(&soundLength, FMOD_TIMEUNIT_PCM);
        ERRCHECK(result);

        *toSound = this->recSound;
    }

    void FMODDevice::StopRecording()
    {
        if (this->recId > -1)
        {
            result = this->system->recordStop(this->recId);
            ERRCHECK(result);
        }

        if (this->recChannel != NULL)
        {
            result = this->recChannel->stop();
            ERRCHECK(result);

            if (this->recCaptureDSP)
            {
                result = this->recChannel->removeDSP(this->recCaptureDSP);
                ERRCHECK(result);

                result = this->recCaptureDSP->release();
                ERRCHECK(result);

                this->recCaptureDSP = NULL;
            }

            this->recChannel = NULL;
        }

        if (this->recSound != NULL)
        {
            result = this->recSound->release();
            ERRCHECK(result);

            this->recSound = NULL;
        }
    }

    void FMODDevice::UpdateRecording(float* intoBuffer, unsigned int length, int channels)
    {
        /*
            Determine how much has been recorded since we last checked
        */
        unsigned int recordPos = 0;
        result = system->getRecordPosition(this->recId, &recordPos);
        if (result != FMOD_ERR_RECORD_DISCONNECTED)
        {
            ERRCHECK(result);
        }
        
#if (0)
        /*
        * sound lock
        */
        if (recordPos != lastRecordPos)
        {
            int recordDelta = (int)recordPos - (int)lastRecordPos;
            if (recordDelta < 0)
                recordDelta += (int)soundLength;

            // Debug.LogFormat("Rec delta {0} | {1} - {2} |", this.recordDelta, this.recordpos, lastRecordPos);

            unsigned int offset = (unsigned int)(lastRecordPos * channelSize * nativeChannels);
            unsigned int length = (unsigned int)(recordDelta * channelSize * nativeChannels);

            void* ptr1 = NULL;
            void* ptr2 = NULL;
            unsigned int len1 = 0;
            unsigned int len2 = 0;

            result = this->recSound->lock(offset, length, &ptr1, &ptr2, &len1, &len2);
            ERRCHECK(result);
            if (result != FMOD_OK)
                return;

            // Write it to output.
            union {
                uint8_t bytes[4];
                float f;
            } UFloat;

            if (ptr1 != NULL && len1 > 0)
            {
                float* fdata = (float*)(ptr1);
                auto fdatalength = (len1) >> 2; // sizeof(float) == 4

                for (unsigned int n = 0; n < fdatalength; n++)
                    this->recBuffer.Feed(fdata[n]);
            }

            if (ptr2 != NULL && len2 > 0)
            {
                float* fdata = (float*)(ptr2);
                auto fdatalength = (len2) >> 2; // sizeof(float) == 4

                for (unsigned int n = 0; n < fdatalength; n++)
                    this->recBuffer.Feed(fdata[n]);
            }

            // Unlock the sound to allow FMOD to use it again.
            result = this->recSound->unlock(ptr1, ptr2, len1, len2);
            ERRCHECK(result);
            if (result != FMOD_OK)
                return;
        }

        lastRecordPos = recordPos;
#elif(1)
        /*
        * system->playSound && channel->setFrequency && channel->addDSP
        */
        unsigned int recordDelta = (recordPos >= lastRecordPos) ? (recordPos - lastRecordPos) : (recordPos + soundLength - lastRecordPos);
        lastRecordPos = recordPos;
        samplesRecorded += recordDelta;

        static unsigned int minRecordDelta = (unsigned int)-1;
        if (recordDelta && (recordDelta < minRecordDelta))
        {
            minRecordDelta = recordDelta; // Smallest driver granularity seen so far //
            adjustedLatency = (recordDelta <= desiredLatency) ? desiredLatency : recordDelta; // Adjust our latency if driver granularity is high //
        }

        //
        // Delay playback until our desired latency is reached.
        //
        if (!this->recChannel && samplesRecorded >= adjustedLatency)
        {
            result = system->playSound(this->recSound, 0, false, &this->recChannel);
            ERRCHECK(result);

            this->recBuffer.Clear();

            this->recCaptureDSP = this->CaptureDSP();
            if (this->recCaptureDSP)
            {
                result = this->recChannel->addDSP(FMOD_CHANNELCONTROL_DSP_TAIL, this->recCaptureDSP);
                ERRCHECK(result);
            }
        }

        if (this->recChannel)
        {
            //
            // Determine how much has been played since we last checked.
            //
            unsigned int playPos = 0;
            result = this->recChannel->getPosition(&playPos, FMOD_TIMEUNIT_PCM);
            ERRCHECK(result);

            static unsigned int lastPlayPos = 0;
            unsigned int playDelta = (playPos >= lastPlayPos) ? (playPos - lastPlayPos) : (playPos + soundLength - lastPlayPos);
            lastPlayPos = playPos;
            samplesPlayed += playDelta;

            //
            // Compensate for any drift.
            //
            int latency = samplesRecorded - samplesPlayed;
            actualLatency = (int)((0.97f * actualLatency) + (0.03f * latency));

            int playbackRate = nativeRate;
            if (actualLatency < (int)(adjustedLatency - driftThreshold))
            {
                // Play position is catching up to the record position, slow playback down by 2% //
                playbackRate = nativeRate - (nativeRate / 50);
            }
            else if (actualLatency > (int)(adjustedLatency + driftThreshold))
            {
                // Play position is falling behind the record position, speed playback up by 2% //
                playbackRate = nativeRate + (nativeRate / 50);
            }

            result = this->recChannel->setFrequency((float)playbackRate);
            ERRCHECK(result);
        }
#endif

        // mix with existing signal
        for (unsigned int n = 0; n < length * channels; n++)
        {
            float val = 0;
            this->recBuffer.Read(val);
            intoBuffer[n] += val;
        }

    }
#pragma endregion
#pragma region capture DSP
    FMOD::DSP* FMODDevice::CaptureDSP()
    {
        /*
            Create the DSP effect.
        */
        FMOD_DSP_DESCRIPTION dspdesc;
        memset(&dspdesc, 0, sizeof(dspdesc));

        strncpy(dspdesc.name, "Channel capture DSP", sizeof(dspdesc.name));
        dspdesc.version = 0x00010000;
        dspdesc.numinputbuffers = 1;
        dspdesc.numoutputbuffers = 1;
        dspdesc.read = readDSPCallback;
        // dspdesc.shouldiprocess = shouldiprocessDSPCallback;
        dspdesc.numparameters = 0;
        dspdesc.paramdesc = NULL;
        dspdesc.userdata = this;

        FMOD::DSP* dsp;
        result = system->createDSP(&dspdesc, &dsp);
        ERRCHECK(result);

        if (result == FMOD_OK)
            return dsp;
        else
            return NULL;
    }
#pragma endregion
    /* !notif
    */
#pragma region Notification cb
    void FMODDevice::Notification_Callback()
    {
        // ignore the 1st call after installation
        if (!this->notifcation_callback_count)
        {
            this->notifcation_callback_count++;
            return;
        }

        this->notifcation_callback();
    }
#pragma endregion
}
