// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#include "Plugin_AudioStreamInputDevice.h"
#include "FMODSystemsManager.h"

/// <summary>
/// - single system (0) for notifications about devices changes
/// - recording system
/// - ASIO requires exclusive single system
/// </summary>
extern AudioStreamDevice::FMODDevice* default0_system;
/* !notif
*/
extern bool invalidate_devices;

namespace AudioStreamInputDevice
{
    int InternalRegisterEffectDefinition(UnityAudioEffectDefinition& definition)
	{
		int numparams = P_NUM;
		definition.paramdefs = new UnityAudioParameterDefinition[numparams];
		// name length *MUST* fit below 16 characters (char[16] in struct definition) <- runtime assert otherwise..
		AudioPluginUtil::RegisterParameter(definition, "InputDevice ID", "(ID)", -1, 255, -1, 1, 1, P_INPUTDEVICEID, "System's input device ID which signal will be recorder and played via this mixer group.\r\nDefault (-1) to ignore\r\n\r\nYou can change input device while playing");
		// RegisterParameter(definition, "DSPBufferLength", "b", 64, 4096, 1024, 1.0f, 1.0f, P_DSPBUFFERLENGTH, "Changing this should only be needed when using Unity's Best latency audio setting and experiencing pops/dropouts in the audio, or having troubles playing on certain outputs - can be left at default (1024/4) otherwise\r\n\r\n- you can try to lower/match default FMOD latency which is used for redirection to Unity ones - DSP buffer size should be 256/4 for Unity's Best latency setting\r\nNote: You probably won't get rid of them entirely, esp. in the Editor - IL2CPP build on 4.6 runtime might help further, but unfortunately it doesn't seem to help in all cases - use other than Best latency if possible in that case\r\n\r\nPlease restart redirection manually after changing this (you can stop play mode or change output device id to do this)");
		// RegisterParameter(definition, "DSPBufferCount", "", 2, 16, 4, 1.0f, 1.0f, P_DSPBUFFERCOUNT, "Changing this should only be needed when using Unity's Best latency audio setting and experiencing pops/dropouts in the audio, or having troubles playing on certain outputs - can be left at default (1024/4) otherwise\r\n\r\n- you can try to lower/match default FMOD latency which is used for redirection to Unity ones - DSP buffer size should be 256/4 for Unity's Best latency setting\r\nNote: You probably won't get rid of them entirely, esp. in the Editor - IL2CPP build on 4.6 runtime might help further, but unfortunately it doesn't seem to help in all cases - use other than Best latency if possible in that case\r\n\r\nPlease restart redirection manually after changing this (you can stop play mode or change output device id to do this)");

		return numparams;
	}

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK CreateCallback(UnityAudioEffectState* state)
    {
        EffectData* data = new EffectData;
        memset(data, 0, sizeof(EffectData));

        AudioPluginUtil::InitParametersFromDefinitions(InternalRegisterEffectDefinition, data->parameters);

        state->effectdata = data;

        AudioStreamDevice::invalidate_effectdataI[data] = false;

        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK ReleaseCallback(UnityAudioEffectState* state)
    {
        EffectData* data = state->GetEffectData<EffectData>();
        delete data;

        AudioStreamDevice::ReleaseAllDevices();

        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK SetFloatParameterCallback(UnityAudioEffectState* state, int index, float value)
    {
        EffectData* data = state->GetEffectData<EffectData>();

        if (index >= P_NUM)
            return UNITY_AUDIODSP_ERR_UNSUPPORTED;

        // store (rounded) value in the context to be retrieved by processing

        switch (index)
        {
        case P_INPUTDEVICEID:
            if ((SInt32)value != data->parameters[index])
                AudioStreamDevice::StopRecording(data);
            break;

        default:
            break;
        }

        data->parameters[index] = value;

        return UNITY_AUDIODSP_OK;
    }

    // looks like this is for (custom) UI - ignore for now
    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK GetFloatParameterCallback(UnityAudioEffectState* state, int index, float* value, char* valuestr)
    {
        EffectData* data = state->GetEffectData<EffectData>();
        if (index >= P_NUM)
            return UNITY_AUDIODSP_ERR_UNSUPPORTED;
        if (value != NULL)
            *value = data->parameters[index];
        if (valuestr != NULL)
            valuestr[0] = 0;
        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK GetFloatBufferCallback(UnityAudioEffectState* state, const char* name, float* buffer, int numsamples)
    {
        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK ProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
    {
        /*
        * mixer state
        *
        * mixer                             state->flags
        * (incl. editor paused)
        *
        * !solo !mute !bypass               UnityAudioEffectStateFlags_IsPlaying
        *
        * muted                             5 == UnityAudioEffectStateFlags_IsPlaying | UnityAudioEffectStateFlags_IsMuted (editor only)
        *
        * solo + any                        ProcessCallback not called (.?.)
        *
        * bypass                            ProcessCallback not called
        *
        * => can be muted in the editor, otherwise proceed normally
        */

        EffectData* data = state->GetEffectData<EffectData>();

        if (
            state->flags & UnityAudioEffectStateFlags_IsMuted
            )
        {
            // 0 output
            memset(outbuffer, 0, sizeof(float) * length * outchannels);

            // update systems

            if (default0_system
                )
                default0_system->Update();

            return UNITY_AUDIODSP_OK;
        }
        else
        {
            // init effect output - mix in incoming signal
            memcpy(outbuffer, inbuffer, sizeof(float) * length * inchannels);
            // memset(outbuffer, 0, sizeof(float) * length * outchannels);
        }

        /* !notif
        */
        if (invalidate_devices)
        {
            invalidate_devices = false;

            AudioStreamDevice::ReleaseAllDevices();

            return UNITY_AUDIODSP_OK;
        }
        // + clear data
        if (AudioStreamDevice::invalidate_effectdataI[data])
        {
            data->recSound = NULL;
            AudioStreamDevice::invalidate_effectdataI[data] = false;
        }

        /*
        * def. system
        */
        // . notifications + recording + // !1 ASIO
        if (!default0_system)
        {
            /* !notif
            */
            default0_system = new AudioStreamDevice::FMODDevice(0, state->samplerate, &AudioStreamDevice::DevicesChanged);
            // default0_system = new AudioStreamDevice::FMODDevice(0, state->samplerate, NULL);
            printf("\n%d system: %d\n", 0, state->samplerate);
        }

        /*
        * restart recording if processing was stopped (~= mixer suspend)
        */
        auto dspdiff = state->currdsptick - state->prevdsptick;
        if (dspdiff > length)
            AudioStreamDevice::StopRecording(data);

        /*
        * processing
        */
        auto inputDeviceID = data->parameters[P_INPUTDEVICEID];

        // forward processing
        // 
        if (inputDeviceID > -1)
            AudioStreamDevice::ProcessCallbackForRecording(data, outbuffer, length, outchannels, state->samplerate);

        /*
        * FMOD update
        */
        if (default0_system
            )
            default0_system->Update();


        return UNITY_AUDIODSP_OK;
    }
}

