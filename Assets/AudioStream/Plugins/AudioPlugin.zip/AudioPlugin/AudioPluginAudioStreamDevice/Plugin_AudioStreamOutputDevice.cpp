// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

// TODO: ERRCHECK does nothing when error

#include "Plugin_AudioStreamOutputDevice.h"
#include "FMODSystemsManager.h"

/// <summary>
/// - single system (0) for notifications about devices changes
/// - recording system
/// - ASIO requires exclusive single system
/// </summary>
extern AudioStreamDevice::FMODDevice* default0_system;
/* !notif
*/
extern bool invalidate_devices;

namespace AudioStreamOutputDevice
{
    int InternalRegisterEffectDefinition(UnityAudioEffectDefinition& definition)
    {
        int numparams = P_NUM;
        definition.paramdefs = new UnityAudioParameterDefinition[numparams];
        // name length *MUST* fit below 16 characters (char[16] in struct definition) <- runtime assert otherwise..
        AudioPluginUtil::RegisterParameter(definition, "OutputDevice ID", "(ID)", -1, 255, -1, 1, 1, P_OUTPUTDEVICEID, "System's output device ID that the mixer signal will be played on.\r\nDefault (-1) to ignore\r\n\r\nYou can change output device while playing");
        AudioPluginUtil::RegisterParameter(definition, "Output Passthru", "(true/false)", 0, 1, 0, 1, 1, P_OUTPUTPASSTHRU, "Pass the signal along in the mixer after redirection/playing on an output if true.\r\n\r\nDefault false (will be played on selected output and then disappear from the mixer group)\r\n\r\nCan be changed while playing");
        // RegisterParameter(definition, "DSPBufferLength", "b", 64, 4096, 1024, 1.0f, 1.0f, P_DSPBUFFERLENGTH, "Changing this should only be needed when using Unity's Best latency audio setting and experiencing pops/dropouts in the audio, or having troubles playing on certain outputs - can be left at default (1024/4) otherwise\r\n\r\n- you can try to lower/match default FMOD latency which is used for redirection to Unity ones - DSP buffer size should be 256/4 for Unity's Best latency setting\r\nNote: You probably won't get rid of them entirely, esp. in the Editor - IL2CPP build on 4.6 runtime might help further, but unfortunately it doesn't seem to help in all cases - use other than Best latency if possible in that case\r\n\r\nPlease restart redirection manually after changing this (you can stop play mode or change output device id to do this)");
        // RegisterParameter(definition, "DSPBufferCount", "", 2, 16, 4, 1.0f, 1.0f, P_DSPBUFFERCOUNT, "Changing this should only be needed when using Unity's Best latency audio setting and experiencing pops/dropouts in the audio, or having troubles playing on certain outputs - can be left at default (1024/4) otherwise\r\n\r\n- you can try to lower/match default FMOD latency which is used for redirection to Unity ones - DSP buffer size should be 256/4 for Unity's Best latency setting\r\nNote: You probably won't get rid of them entirely, esp. in the Editor - IL2CPP build on 4.6 runtime might help further, but unfortunately it doesn't seem to help in all cases - use other than Best latency if possible in that case\r\n\r\nPlease restart redirection manually after changing this (you can stop play mode or change output device id to do this)");

        return numparams;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK CreateCallback(UnityAudioEffectState* state)
    {
        EffectData* data = new EffectData;
        memset(data, 0, sizeof(EffectData));

        AudioPluginUtil::InitParametersFromDefinitions(InternalRegisterEffectDefinition, data->parameters);

        state->effectdata = data;

        AudioStreamDevice::invalidate_effectdataO[data] = false;

        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK ReleaseCallback(UnityAudioEffectState* state)
    {
        EffectData* data = state->GetEffectData<EffectData>();
        delete data;

        AudioStreamDevice::ReleaseAllDevices();

        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK SetFloatParameterCallback(UnityAudioEffectState* state, int index, float value)
    {
        EffectData* data = state->GetEffectData<EffectData>();

        if (index >= P_NUM)
            return UNITY_AUDIODSP_ERR_UNSUPPORTED;

        // store (rounded) value in the context to be retrieved by processing

        switch (index)
        {
        case P_OUTPUTDEVICEID:
            // stop current sound on change
            // (releases FMOD system if necessary; fmod is created lazily later from ProcessCallback)
            if ((SInt32)value != data->parameters[index])
                AudioStreamDevice::StopOutputSound(data);
            break;

        default:
            break;
        }

        data->parameters[index] = value;

        return UNITY_AUDIODSP_OK;
    }

    // looks like this is for (custom) UI - ignore for now
    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK GetFloatParameterCallback(UnityAudioEffectState* state, int index, float* value, char *valuestr)
    {
        EffectData* data = state->GetEffectData<EffectData>();
        if (index >= P_NUM)
            return UNITY_AUDIODSP_ERR_UNSUPPORTED;
        if (value != NULL)
            *value = data->parameters[index];
        if (valuestr != NULL)
            valuestr[0] = 0;
        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK GetFloatBufferCallback(UnityAudioEffectState* state, const char* name, float* buffer, int numsamples)
    {
        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK ProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
    {
        /*
        * mixer state
        * 
        * mixer                             state->flags
        * (incl. editor paused)
        * 
        * !solo !mute !bypass               UnityAudioEffectStateFlags_IsPlaying
        * 
        * muted                             5 == UnityAudioEffectStateFlags_IsPlaying | UnityAudioEffectStateFlags_IsMuted (editor only)
        * 
        * solo + any                        ProcessCallback not called (.?.)
        * 
        * bypass                            ProcessCallback not called
        * 
        * => can be muted in the editor, otherwise proceed normally
        */

        EffectData* data = state->GetEffectData<EffectData>();
        auto outputSystem = AudioStreamDevice::OutputSystem(data);

        if (
            state->flags & UnityAudioEffectStateFlags_IsMuted
            )
        {
            // 0 output
            memset(outbuffer, 0, sizeof(float) * length * inchannels);

            if (data->outputSound)
                AudioStreamDevice::MuteOutputSound(data);

            // update systems
            if (outputSystem != NULL)
                outputSystem->Update();

            if (default0_system
                && default0_system != outputSystem
                )
                default0_system->Update();

            return UNITY_AUDIODSP_OK;
        }
        else
        {
            // init effect output as what's on input
            memcpy(outbuffer, inbuffer, sizeof(float) * length * inchannels);
        }

        /* !notif
        */
        if (invalidate_devices)
        {
            invalidate_devices = false;

            AudioStreamDevice::ReleaseAllDevices();

            return UNITY_AUDIODSP_OK;
        }
        // + clear data
        if (AudioStreamDevice::invalidate_effectdataO[data])
        {
            data->outputSound = NULL;
            AudioStreamDevice::invalidate_effectdataO[data] = false;
        }
        /*
        * def. system
        */
        // . notifications + recording + // !1 ASIO
        if (!default0_system)
        {
            /* !notif
            */
            default0_system = new AudioStreamDevice::FMODDevice(0, state->samplerate, &AudioStreamDevice::DevicesChanged);
            // default0_system = new AudioStreamDevice::FMODDevice(0, state->samplerate, NULL);
            printf("\n%d system: %d\n", 0, state->samplerate);
        }

        /*
        * restart if processing was stopped (~= mixer suspend)
        */
        auto dspdiff = state->currdsptick - state->prevdsptick;
        if (dspdiff > length)
            AudioStreamDevice::StopOutputSound(data);

        /*
        * processing
        */
        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];

        // forward processing
        if (outputDeviceID > -1)
        {
            if (data->outputSound)
                AudioStreamDevice::UnmuteOutputSound(data);

            AudioStreamDevice::ProcessCallbackForOutputDevice(data, inbuffer, length, inchannels, state->samplerate);

            // !passthru remove/0-out output
            auto passthru = (bool)data->parameters[P_OUTPUTPASSTHRU];
            if (!passthru)
                memset(outbuffer, 0, sizeof(float) * length * inchannels);
        }

        /*
        * FMOD update
        */
        if (outputSystem != NULL)
            outputSystem->Update();

        if (default0_system
            && default0_system != outputSystem
            )
            default0_system->Update();


        return UNITY_AUDIODSP_OK;
    }
}
