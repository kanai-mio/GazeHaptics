// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(_WIN64)
#include "..\AudioPluginUtil.h" // this has platforms abstractions apart from plugin convenience macros, mainly
#include "..\AudioPluginInterface.h"
#else
#include "AudioPluginUtil.h"
#include "AudioPluginInterface.h" // Xcode added files are found
#endif
#include "fmod.hpp"
#include "fmod_common.h"
#include <list>
#include <map>
#include <iterator>
#include <mutex>
using namespace std;

namespace AudioStreamDevice
{
#pragma region //(temp) ASIO buffers
    static bool use_ASIO =
#if WIN_ASIO
        true
#else
        false
#endif
        ;
    static unsigned int ASIO_bufferlength = 512;
    static int ASIO_numbuffers = 4;
#pragma endregion

    class RingBuffer_ThreadSafe
    {
        AudioPluginUtil::RingBuffer<480000, float> m;
        mutable std::mutex _mtx;

    public:
        inline bool Read(float& val)
        {
            std::lock_guard<std::mutex> l(_mtx);
            return m.Read(val);
        }

        inline bool Feed(const float& input)
        {
            std::lock_guard<std::mutex> l(_mtx);
            return m.Feed(input);
        }

        inline void Clear()
        {
            std::lock_guard<std::mutex> l(_mtx);
            m.Clear();
        }
    };

#define LATENCY_MS      (50) /* Some devices will require higher latency to avoid glitches */
#define DRIFT_MS        (1)

    class FMODDevice
    {
    public:
        FMODDevice(UInt32 outputDeviceID, UInt32 samplerate, void(*notification_cb)());
        ~FMODDevice();

        void Update();

        void Feed(FMOD::Sound* sound, const float* input, unsigned int length);

        void MuteOutputSound(FMOD::Sound* sound);
        void UnmuteOutputSound(FMOD::Sound* sound);

        void StartOutputSound(FMOD::Sound** sound, int inchannels, UInt32 insamplerate);
        void StopOutputSound(FMOD::Sound* sound);

        void StartRecording(FMOD::Sound** toSound, unsigned int ofInput, int channels, UInt32 samplerate);
        void StopRecording();
        void UpdateRecording(float* intoBuffer, unsigned int length, int channels);

        /* !notif
        */
        void Notification_Callback();
        RingBuffer_ThreadSafe recBuffer;

    private:
        FMOD::System    *system = NULL;
        list<FMOD::Sound*> outputSounds;

        FMOD::Sound* recSound;
        FMOD::Channel* recChannel;
        FMOD::DSP* recCaptureDSP;
        int recId;
        FMOD::DSP* CaptureDSP();

        FMOD_RESULT     result = FMOD_OK;
        unsigned int    version = 0;
        void(*notifcation_callback)() = NULL;
        int notifcation_callback_count = 0; // ignore the 1st call after installation

        // FMOD SoundSystem\FMOD Studio API Windows\api\core\examples\record.cpp
        unsigned int samplesRecorded = 0;
        unsigned int samplesPlayed = 0;

        int nativeRate = 0;
        unsigned int driftThreshold;
        unsigned int desiredLatency;    /* User specified latency */
        unsigned int adjustedLatency;   /* User specified latency adjusted for driver update granularity */
        int actualLatency;

        unsigned int soundLength = 0;
        int channelSize = sizeof(float);
        int nativeChannels = 0;

        unsigned int lastRecordPos = 0;
    };
}
