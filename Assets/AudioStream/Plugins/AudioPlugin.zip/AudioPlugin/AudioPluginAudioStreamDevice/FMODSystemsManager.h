// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once
#include "Plugin_AudioStreamOutputDevice.h"
#include "Plugin_AudioStreamInputDevice.h"

namespace AudioStreamDevice
{
    // Output - FMOD Systems
    static std::map<UInt32, FMODDevice*> outputSystems;
    static AudioPluginUtil::Mutex outputMutex;  // pcmbuffers sync feed/sound
    /// <summary>
    /// find system based on data -> parameter
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    FMODDevice* OutputSystem(AudioStreamOutputDevice::EffectData* fromData);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="fromData"></param>
    /// <returns></returns>
    FMODDevice* InputSystem(AudioStreamInputDevice::EffectData* fromData);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <param name="inbuffer"></param>
    /// <param name="length"></param>
    /// <param name="inchannels"></param>
    /// <param name="samplerate"></param>
    void ProcessCallbackForOutputDevice(AudioStreamOutputDevice::EffectData *data, float* inbuffer, unsigned int length, int inchannels, UInt32 samplerate);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <param name="outbufer"></param>
    /// <param name="length"></param>
    /// <param name="outchannels"></param>
    /// <param name="samplerate"></param>
    void ProcessCallbackForRecording(AudioStreamInputDevice::EffectData* data, float* outbufer, unsigned int length, int outchannels, UInt32 samplerate);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    // void ReleaseDevice(AudioStreamOutputDevice::EffectData* data);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void MuteOutputSound(AudioStreamOutputDevice::EffectData*data);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void UnmuteOutputSound(AudioStreamOutputDevice::EffectData* data);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void StartOutputSound(AudioStreamOutputDevice::EffectData* data, int inchannels, UInt32 insamplerate);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void StopOutputSound(AudioStreamOutputDevice::EffectData* data);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <param name="forInput"></param>
    /// <param name="insamplerate"></param>
    void StartRecording(AudioStreamInputDevice::EffectData* data, unsigned int ofInput, int channels, UInt32 samplerate);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void StopRecording(AudioStreamInputDevice::EffectData* data);
    /* !notif
    */
    /// <summary>
    /// 
    /// </summary>
    void DevicesChanged();
    /// <summary>
    /// 
    /// </summary>
    extern std::map<AudioStreamOutputDevice::EffectData*, bool> invalidate_effectdataO;
    extern std::map<AudioStreamInputDevice::EffectData*, bool> invalidate_effectdataI;
    /// <summary>
    /// 
    /// </summary>
    void ReleaseAllDevices();
}
