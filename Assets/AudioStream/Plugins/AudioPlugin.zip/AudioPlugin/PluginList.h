// (c) 2016-2023 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#if !WIN_ASIO
DECLARE_EFFECT("AudioStream OutputDevice", AudioStreamOutputDevice)
DECLARE_EFFECT("AudioStream InputDevice", AudioStreamInputDevice)
#else
DECLARE_EFFECT("AudioStream ASIO OutputDevice", AudioStreamOutputDevice)
DECLARE_EFFECT("AudioStream ASIO InputDevice", AudioStreamInputDevice)
#endif // WIN_ASIO
